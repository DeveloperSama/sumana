package com.mvc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	@RequestMapping("/login")
	//we can use @RequestParam..to get user data to controller
	public ModelAndView helloWorld(HttpServletRequest request, HttpServletResponse res){
	String name=request.getParameter("uname");
	String password=request.getParameter("pass");
	//System.out.println(password);
if(password.equals("admin")){
	String message="HELLO" +name;
	ModelAndView mv=new ModelAndView();
	mv.addObject("print",message);
	mv.setViewName("hellopage");
	return mv;
}
else{
	return new ModelAndView("error","message","sorry username or password error" );
	
}
}
}