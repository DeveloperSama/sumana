package com.pwd.WelcomeApp;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	private int empId;
	private String empName;
	
@Autowired
	private AddressEmp add;


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	/*public AddressEmp getAdd() {
		return add;
	}

@Autowired
	public void setAdd(AddressEmp add) {
		this.add = add;
	}*/
	
	
	
	
	public void display()
	{
		System.out.println("EmployeeId:"+empId);
		System.out.println("EmployeeId:"+empName);
		this.add.setHno(1999);
		this.add.setCity("hyd");
		this.add.setColony("velgatoor");
		System.out.println(add);
	}
}
