package com.pwd.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class validation {
	
	@RequestMapping("/validate")
	public ModelAndView validate(@RequestParam("uname") String user, @RequestParam("pass") String pwd){
		System.out.println(user+"  "+pwd);
		String result;
		ModelAndView mv=new ModelAndView();
		if(user.equals(pwd)){
			result="Success";
			mv.setViewName("welcome.jsp");
			mv.addObject(result);
			return mv;
		}else
			result="Failure";
		mv.setViewName("error.jsp");
		mv.addObject(result);
		return mv;
	}
	

}
