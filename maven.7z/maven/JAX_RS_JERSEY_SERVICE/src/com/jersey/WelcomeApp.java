package com.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

@Path("/WelcomeSampleService")
public class WelcomeApp {

	@GET
	@Path("/pathParam/{name1}/{age1}")
	public String display1(@PathParam("name1") String name, @PathParam("age1") int age) {
		return "Welcome " + name + " and Your Age is " + age + " -->PathParam Annotaction";
	}

	@GET
	@Path("/queryParam")
	public String display2(@QueryParam("name1") String name, @QueryParam("age1") int age) {
		return "Welcome " + name + " and Your Age is " + age + " -->QueryParam Annotaction";
	}
}
//http://localhost:8564/JAX_RS_JERSEY_SERVICE/rest/WelcomeSampleService/pathParam/?santosh/&80
//http://localhost:8564/JAX_RS_JERSEY_SERVICE/rest/WelcomeSampleService/queryParam/?name1=santosh&age1=80