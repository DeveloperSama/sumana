package org.cap.dao;



import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.entities.User;
import org.springframework.stereotype.Repository;


/**
* marking with @Repository is similar to @Component but used for Dao implementation classes,
* spring will keep instance of DetailsDaoImpl and the object will be kept in bean factory
*
*/



@Repository//@Service,@Component,@Enitty
public class DetailsDaoImpl implements IDetailsDao {
    
@PersistenceContext
    private EntityManager em;


    public DetailsDaoImpl(){
    }


    public User findUserById(int id) {
      User u= em.find(User.class,id);
      return u;
    }


    public User createUser(User user){
        user=em.merge(user);
        return user;
    }


    public User createUser(String name) {
        User user=new User();
        user.setName(name);
        user=em.merge(user);
        return user;
    }
}










