package com.cap.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cap.dao.TransactionRepo;
//import com.cap.entities.InvoiceDetails;
import com.cap.entities.TransactionDetails;

	@Service("transactionService")
	public class TransactionServiceImpl implements TransactionService{

		@Autowired
		TransactionRepo transactionDao;
		
		@Autowired
		CartService cartService;
		
		@Override
		public List<TransactionDetails> getAllTransactions() {
			return transactionDao.findAll();
		}

		@Override
		public TransactionDetails getTransaction(Long transactionId) { //Team 6
			Optional<TransactionDetails> optional = transactionDao.findByTransactionId(transactionId);
			if(optional.isPresent()) {
				return optional.get();
			}
			return null;
		}

		@Override
		public boolean insertTransaction(TransactionDetails transaction) {//Team 6
			transactionDao.save(transaction);
			  
			return true;
		}
		
		/*@Override
		public TransactionDetails getTransactionFromInvoice(InvoiceDetails invoice) {
			
			return transactionDao.getTransactionFromInvoice(invoice);
		}*/
		
		
	}

