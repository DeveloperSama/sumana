package com.cap.exception;

@SuppressWarnings("serial")
public class CustomerCreationException extends RuntimeException{

	public CustomerCreationException(String errMsg) {
		super(errMsg);
		
	}
	

}
