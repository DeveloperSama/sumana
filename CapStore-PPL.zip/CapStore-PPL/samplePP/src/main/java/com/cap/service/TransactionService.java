package com.cap.service;

import java.util.List;
//import com.cap.entities.InvoiceDetails;
import com.cap.entities.TransactionDetails;
	
	public interface TransactionService {
		
		public List<TransactionDetails> getAllTransactions();
		
		public TransactionDetails getTransaction(Long transactionId);

		public boolean insertTransaction(TransactionDetails transaction);

		//public TransactionDetails getTransactionFromInvoice(InvoiceDetails invoice);	
		
	}

