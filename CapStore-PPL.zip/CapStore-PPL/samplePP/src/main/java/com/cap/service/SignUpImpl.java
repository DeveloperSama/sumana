package com.cap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.CustomerRepo;
import com.cap.entities.Customer;
import com.cap.exception.CustomerCreationException;
import com.cap.util.Encryption;


@Service("signUp")
public class SignUpImpl implements SignUp{
	
	@Autowired
	CustomerRepo dao;

	
	public Customer createCustomerAccount(Customer custReg) {
		
		Customer customer=dao.save(custReg);
		if(customer==null) {
			throw new CustomerCreationException("Customer Account is Not Created");
		}
		else
		{
			customer.setCustomer_Password(Encryption.encrypt(custReg.getCustomer_Password()));
			customer.setCustomer_ReEnterPassword(Encryption.encrypt(custReg.getCustomer_ReEnterPassword()));
		}
	return customer;
	}
}
