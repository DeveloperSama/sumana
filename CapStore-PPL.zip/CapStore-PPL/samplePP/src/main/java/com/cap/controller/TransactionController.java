package com.cap.controller;

import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cap.entities.TransactionDetails;
import com.cap.service.CartService;
import com.cap.service.InvoiceService;
import com.cap.service.OrderService;
import com.cap.service.TransactionService;

@SuppressWarnings({ "unchecked", "rawtypes" })
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/capstore")
public class TransactionController {
	
		TransactionDetails transactionDeatils; 

		@Autowired
		TransactionService transactionService;

		@Autowired
		InvoiceService invoiceService;

		@Autowired
		OrderService orderService;
		
		@Autowired
		CartService cartService;

		@GetMapping("/transaction")
		public ResponseEntity<List<TransactionDetails>> getAllTransactions(HttpSession session) {// Team 6
			List<TransactionDetails> transactions = transactionService.getAllTransactions();
			if (transactions.isEmpty()) {
				return new ResponseEntity("Transactions not found", HttpStatus.OK);
			}
			return new ResponseEntity<List<TransactionDetails>>(transactions, HttpStatus.OK);
		}

		@GetMapping("/transaction/{transactionId}")//
		public ResponseEntity<TransactionDetails> getTransaction(@PathVariable("transactionId") Long transactionId) {// Team 6
			TransactionDetails transaction = transactionService.getTransaction(transactionId);
			if (transaction == null)
				return new ResponseEntity("Sorry! Transaction is not available!", HttpStatus.NOT_FOUND);
			return new ResponseEntity<TransactionDetails>(transaction, HttpStatus.OK);
		}

		@PostMapping("/transaction")//
		public ResponseEntity<Boolean> insertTransaction(@RequestBody TransactionDetails transaction) {// Team 6
			transactionService.insertTransaction(transaction);
			if (transactionService.insertTransaction(transaction)) {
				return new ResponseEntity<Boolean>(true, HttpStatus.OK);
			} else {
				return new ResponseEntity<Boolean>(false, HttpStatus.OK);
			}
		}
	}