package com.cap.service;

import com.cap.entities.Customer;

public interface ForgotPassword {
	public Customer findByCustomerEmailForPasswd(String customer_Email, String customer_Password);
	
	public Customer findByCustomerMobNum(String customer_MobileNumber,String customer_Question,String customer_Answer,String customer_Password);
}
