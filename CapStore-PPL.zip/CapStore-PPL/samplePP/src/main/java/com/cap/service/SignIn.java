package com.cap.service;

import com.cap.entities.Customer;

public interface SignIn {
	public Customer findByCustomerEmail(String customer_Email,String customer_Password);
}
