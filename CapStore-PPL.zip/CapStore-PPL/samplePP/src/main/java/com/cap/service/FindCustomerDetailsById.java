package com.cap.service;

import com.cap.entities.Customer;

public interface FindCustomerDetailsById {
	public Customer findCustomerById(long customer_Id);

}
