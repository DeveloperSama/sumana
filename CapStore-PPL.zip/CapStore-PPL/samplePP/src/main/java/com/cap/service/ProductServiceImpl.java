package com.cap.service;

import org.springframework.stereotype.Service;
import com.cap.entities.Product;

@Service("productService")
public class ProductServiceImpl implements ProductService {

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

}
