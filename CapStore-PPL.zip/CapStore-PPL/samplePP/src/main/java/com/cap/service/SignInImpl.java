package com.cap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.CustomerRepo;
import com.cap.entities.Customer;
import com.cap.util.Decryption;


@Service("signIn")
public class SignInImpl implements SignIn{
	
	@Autowired
	CustomerRepo dao;
	
	Customer customer;
	
	
	public Customer findByCustomerEmail(String customer_Email, String customer_Password) {
		customer=dao.findByCustomerEmail(customer_Email, customer_Password);
		String cust_Email=customer.getCustomer_Email();
		customer.setCustomer_Password(Decryption.decrypt(customer.getCustomer_Password()));
		String cust_passwd=customer.getCustomer_Password();
		if(cust_Email.equals(customer_Email)&&cust_passwd.equals(customer_Password)) {
			System.out.println("Login Successfully");
		}
		return customer;
	}
}
