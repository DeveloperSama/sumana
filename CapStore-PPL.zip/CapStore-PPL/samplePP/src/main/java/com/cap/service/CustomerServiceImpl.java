package com.cap.service;

import org.springframework.stereotype.Service;
import com.cap.entities.Customer;


@Service("customerService")
public class CustomerServiceImpl implements CustomerService{

	@Override
	public Customer getCustomerByCustomerId(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

}
