package com.cap.service;

import org.springframework.stereotype.Service;

import com.cap.entities.Order;

@Service("orderService")
public class OrderServiceImpl implements OrderService {

	@Override
	public Order findOrderById(int orderId) {
		// TODO Auto-generated method stub
		return null;
	}

}
