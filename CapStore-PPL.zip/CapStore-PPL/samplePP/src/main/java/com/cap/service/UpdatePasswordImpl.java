package com.cap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.CustomerRepo;
import com.cap.entities.Customer;
import com.cap.util.Decryption;
import com.cap.util.Encryption;


@Service("updatePassword")
public class UpdatePasswordImpl implements UpdatePassword{

	@Autowired
	CustomerRepo dao;
	
	Customer customer;
	
	
	
	public Customer updateCustomerPassword(String customer_Email, String customer_Password,
			String customer_ReEnterPassword) {
		customer=dao.updateCustomerPassword(customer_Email, customer_Password, customer_ReEnterPassword);
		String cust_Email=customer.getCustomer_Email();
		customer.setCustomer_Password(Decryption.decrypt(customer.getCustomer_Password()));
		String current_Passwd=customer.getCustomer_Password();
		if(current_Passwd.equals(customer_Password)&&cust_Email.equals(customer_Email)) {
			customer.setCustomer_Password(Encryption.encrypt(customer_ReEnterPassword));
			customer.setCustomer_ReEnterPassword(Encryption.encrypt(customer_ReEnterPassword));
			dao.save(customer);
		}
		return customer;
	}

}
