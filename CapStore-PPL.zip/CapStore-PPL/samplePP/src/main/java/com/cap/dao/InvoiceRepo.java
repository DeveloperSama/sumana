package com.cap.dao;

import java.util.Date;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.cap.entities.InvoiceDetails;


@Repository("invoiceRepo")
@Transactional
public interface InvoiceRepo extends JpaRepository<InvoiceDetails,Integer> {

	@Query("select count(*) from InvoiceDetails where invoiceDate between :fromDate and :toDate")
	public List<InvoiceDetails> getInvoiceDetailsBetweenDates(Date fromDate, Date toDate);

}