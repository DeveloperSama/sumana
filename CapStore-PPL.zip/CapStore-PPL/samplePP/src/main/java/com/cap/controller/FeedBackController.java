package com.cap.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cap.entities.FeedBack;
import com.cap.entities.Merchant;
import com.cap.service.CustomerService;
import com.cap.service.FeedBackService;
import com.cap.service.MerchantService;
import com.cap.service.ProductService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/capstore")
public class FeedBackController {

	@Autowired
	FeedBackService feedBackService;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	ProductService productService;
	
	@Autowired
	MerchantService merchantService;
	
	@PostMapping("/feedback/{customer_Id}/{merchant_Id}/{productId}")
	public ResponseEntity<Boolean> submitFeedback(
			@PathVariable("customer_Id")int customer_Id, @PathVariable("merchant_Id") int merchant_Id,
			@PathVariable("productId") int productId){
		FeedBack feedBack = new FeedBack();
		   feedBack.setCustomer(customerService.getCustomerByCustomerId(customer_Id));
		   feedBack.setMerchant(merchantService.getMerchantByMerchantId(merchant_Id));
		   feedBack.setProduct(productService.getProduct(productId));
		   feedBackService.submitFeedback(feedBack);
		return new ResponseEntity<Boolean>(true,HttpStatus.OK);
	}
	
	@GetMapping("/allFeedbacks")
	public ResponseEntity<List<FeedBack>> getAllFeedbacks(){
		List<FeedBack> feedBack=feedBackService.getAllFeedbacksOrderByMerchantId();
		System.out.println(feedBack);
		return new ResponseEntity<List<FeedBack>>(feedBack,HttpStatus.OK);
	}
	
	@GetMapping("/getNumberOfFeedbacksPerMerchant")
	public ResponseEntity<List<Long>> getNumberOfFeedbacksPerMerchant(){
		List<Long> feedbacks=feedBackService.getNumberOfFeedbacksPerMerchant();
		System.out.println("dsfs"+feedbacks);
		return new ResponseEntity<List<Long>>(feedbacks,HttpStatus.OK);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/feedback/{productId}")
	public ResponseEntity<List<FeedBack>> getAllFeedbacks(@PathVariable int productId){
		List<FeedBack> feedBack=feedBackService.getAllFeedbacks(productId);
		if(feedBack.isEmpty())
		{
			return new ResponseEntity("Sorry! No Feedbacks Found!",HttpStatus.NOT_FOUND);
		}
		else
		{
		return new ResponseEntity<List<FeedBack>>(feedBack,HttpStatus.OK);
	}
	}
	@GetMapping("/merchantFeedback/{mailId}")
	public ResponseEntity<List<FeedBack>> getMerchantFeedbacks(@PathVariable("mailId") String mailId){

		Merchant merchant=merchantService.getMerchantByMail(mailId);

		List<FeedBack> feedbacks=feedBackService.getAllFeedbacksOfMerchant(merchant.getMerchant_Id());

		if(feedbacks.isEmpty())
			return new ResponseEntity<List<FeedBack>>(feedbacks,HttpStatus.OK);
		else
		return new ResponseEntity<List<FeedBack>>(feedbacks,HttpStatus.OK);

	}

}
