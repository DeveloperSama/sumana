package com.cap.service;

import java.util.List;

import com.cap.entities.FeedBack;

public interface FeedBackService {
		
	public void submitFeedback(FeedBack feedBack);
	
	public double calculateProductRating(int productId);
	
	public List<FeedBack> getAllFeedbacks(int productId);
	
	public List<FeedBack> getAllFeedbacksOrderByMerchantId();

	public List<Long> getNumberOfFeedbacksPerMerchant();

	public List<FeedBack> getAllFeedbacksOfMerchant(int merchant_Id);
}
