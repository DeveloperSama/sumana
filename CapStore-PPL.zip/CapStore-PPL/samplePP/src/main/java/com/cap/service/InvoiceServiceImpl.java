package com.cap.service;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cap.dao.InvoiceRepo;
import com.cap.entities.InvoiceDetails;
import com.cap.entities.Order;

@Service("invoiceService")
public class InvoiceServiceImpl implements InvoiceService{

	@Autowired
	InvoiceRepo invoiceDao;
	
	@Autowired
	OrderService orderService;
	
	
	@Override
	public InvoiceDetails getInvoiceFromOrderId(int OrderId) {
		
		Order myOrder = orderService.findOrderById(OrderId);
		
		List<InvoiceDetails> invoices = invoiceDao.findAll();
		
		for(InvoiceDetails myInvoice: invoices) {
			if(myInvoice.getOrder().equals(myOrder)) {
				return myInvoice;
			}
		}
		return null;
	}

	@Override
	public boolean generateInvoice(InvoiceDetails invoice) {
		
		invoiceDao.save(invoice);
		
		return true;
	}

	@Override
	public List<InvoiceDetails> getInvoiceDetailsBetweenDates(Date fromDate, Date toDate) {
		List<InvoiceDetails> invoiceDetails=invoiceDao.getInvoiceDetailsBetweenDates(fromDate, toDate);
		return invoiceDetails;
	}

	@Override
	public InvoiceDetails insertInvoice(InvoiceDetails invoice) {
		InvoiceDetails invoiceDetails=invoiceDao.save(invoice);
		return invoiceDetails;
	}
	
}
	

