package com.cap.controller;

import java.util.List;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cap.entities.Merchant;
import com.cap.entities.Product;
import com.cap.service.MerchantService;

@RestController
@CrossOrigin(origins ="*")
@RequestMapping("/capstore")
public class MerchantController {
	
	
	MerchantService service;
	
	@PostMapping("/addMerchant")
	public Merchant addMerchant(@RequestBody Merchant merchant) {
	return	service.addMerchant(merchant);
	}
	
	@PostMapping("/addProduct")
	public List<Product> addProduct(@RequestBody Product product) {
		return	service.addProduct(product);
		
	}
	/*
	@GetMapping("/fetchProduct/{productId}")
    public Optional<Product> fetchProduct(@PathVariable long productId) {
    return    service.fetchProduct(productId);
    }
   
    @PostMapping("/addProduct")
    public List<Product> addProducts(@RequestBody Product product) {
        return service.addProduct(product);
    }
*/
}
