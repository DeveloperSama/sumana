package com.cap.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cap.entities.InvoiceDetails;
import com.cap.service.InvoiceService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/capstore")
public class InvoiceController {
	
	@Autowired
	private InvoiceService invoiceService;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping(value = "/invoice")
	public ResponseEntity<InvoiceDetails> insertShipment(@RequestBody InvoiceDetails invoice) {
		System.out.println("Add Customer");
		System.out.println(invoice);
		
		InvoiceDetails invoice1=invoiceService.insertInvoice(invoice);
		
		if(invoice==null)
			return new ResponseEntity("Insertion Failed",HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<InvoiceDetails>(invoice1,HttpStatus.OK);
	}
	
	@GetMapping(value = "/getInvoice/{OrderId}")
	public ResponseEntity<InvoiceDetails> getInvoice(@PathVariable("OrderId") Integer orderId){
		
		InvoiceDetails requiredInvoice = invoiceService.getInvoiceFromOrderId(orderId);
		
		return new ResponseEntity<InvoiceDetails>(requiredInvoice, HttpStatus.OK);
		
	}
}