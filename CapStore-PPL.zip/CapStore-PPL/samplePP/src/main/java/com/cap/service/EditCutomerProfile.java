package com.cap.service;

import com.cap.entities.Customer;

public interface EditCutomerProfile {
	public Customer editCustomerProfile(String customer_Email,String customer_Name,String customer_HomeAddress,String customer_ShippingAddress,String customer_MobileNumber);
}
