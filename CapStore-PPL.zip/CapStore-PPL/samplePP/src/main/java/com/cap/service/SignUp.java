package com.cap.service;

import com.cap.entities.Customer;

public interface SignUp {
	public Customer createCustomerAccount(Customer custReg);
}
