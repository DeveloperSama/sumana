package com.cap.service;

import org.springframework.stereotype.Service;

import com.cap.entities.Order;

@Service
public interface OrderService {

	Order findOrderById(int orderId);

}
