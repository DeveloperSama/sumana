package com.cap.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cap.entities.Customer;


@Repository("customerRepo")
@Transactional
public interface CustomerRepo extends JpaRepository<Customer,Long>{
	
	@Query("from Customer where customer_Email=?1")
	public Customer findByCustomerEmail(String customer_Email,String customer_Password);
	
	@Query("from Customer where customer_Email=?1")
	public Customer findByCustomerEmailForPasswd(String customer_Email, String customer_Password);

	@Query("from Customer where customer_MobileNumber=?1")
	public Customer findByCustomerMobNum(String customer_MobileNumber,String customer_Question,String customer_Answer,String customer_Password);
	
	@Query("from Customer where customer_Email=?1")
	public Customer updateCustomerPassword(String customer_Email, String customer_Password,String customer_ReEnterPassword);
	
	@Query("from Customer where customer_Email=?1")
	public Customer editCustomerProfile(String customer_Email,String customer_Name,String customer_HomeAddress,String customer_ShippingAddress,String customer_MobileNumber);

}
