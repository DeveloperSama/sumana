package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_products")
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "product_seq_gen")
	@SequenceGenerator(name = "product_seq_gen", initialValue = 1000, sequenceName = "product_seq")
	private long productId;

	@Column(length = 20)
	private String productType;
	
	// @ForeignKey(name="merchanEmail")
	@Column(length = 50)
	private String productName;
	@Column(length = 10)
	private double productPrice;
	@Column(length = 100)
	private String productDescription;
	@Column(length = 100)
	private int productAvailability;
	/*@OneToOne
	@JoinColumn
	private FeedBackDetails feedBack;*/
	
	//@ManyToOne(fetch = FetchType.LAZY)
	//@JoinTable( name = "Answer", joinColumns = @JoinColumn ( name = "question_id"),
	//@JoinColumn(name = "email")
	//@OneToMany(fetch = FetchType.LAZY)
	//@JoinTable(name="capstore_merchants", joinColumns=@JoinColumn(name="email"))
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="merchant_Id",referencedColumnName="merchant_Id")
	private Merchant merchant;

	
	/*public FeedBackDetails getFeedBack() {
		return feedBack;
	}

	public void setFeedBack(FeedBackDetails feedBack) {
		this.feedBack = feedBack;
	}*/

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public int getProductAvailability() {
		return productAvailability;
	}

	public void setProductAvailability(int productAvailability) {
		this.productAvailability = productAvailability;
	}

	public Product(long productId, String productType, String productName, double productPrice,
			String productDescription, int productAvailability, Merchant merchant) { //FeedBackDetails feedBack,
		super();
		this.productId = productId;
		this.productType = productType;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productDescription = productDescription;
		this.productAvailability = productAvailability;
		//this.feedBack = feedBack;
		this.merchant = merchant;
	}

	public Product() {
		// TODO Auto-generated constructor stub
	}
}
