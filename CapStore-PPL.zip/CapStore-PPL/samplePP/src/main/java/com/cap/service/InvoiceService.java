package com.cap.service;

import java.util.Date;
import java.util.List;

import com.cap.entities.InvoiceDetails;


public interface InvoiceService {

	public boolean generateInvoice(InvoiceDetails invoice);
	
	public InvoiceDetails getInvoiceFromOrderId(int OrderId);
	
	public List<InvoiceDetails> getInvoiceDetailsBetweenDates(Date fromDate, Date toDate);

	public InvoiceDetails insertInvoice(InvoiceDetails invoice);


}
