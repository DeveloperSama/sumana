package com.cap.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cap.entities.FeedBack;

@Repository("feedBackRepo")
@Transactional
public interface FeedBackRepo extends JpaRepository<FeedBack,Integer> {
	
	@Query("from FeedBack where product.productId=:productId")
	public List<FeedBack> findByProductId(@Param("productId") int productId);
	
	@Query("from FeedBack where merchant.merchant_Id=:merchant_Id")
	public List<FeedBack> findByMerchantId(@Param("merchant_Id") int merchantId);
	
	@Query("from FeedBack order by merchant.merchant_Id")
	public List<FeedBack> findAllOrderByMerchantId();
	
	@Query("select count(*) from FeedBack group by merchant.merchant_Id")
	public List<Long> numberOfFeedbacksPerMerchant();
	
	@Query("from FeedBack WHERE product_product_id=:productId")
	public List<FeedBack> getAllFeedbacks(int productId);
	
}
