package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="capstore_customerlogin")
public class CustomerLogin {
	
    @Id
    @Column(length=30)
    private String customer_Email;
    
    @Column(length=20)
    private String customer_Password;
 
    //Getters And Setters
    public String getCustomer_Email() {
        return customer_Email;
    }
    
    public void setCustomer_Email(String customer_Email) {
        this.customer_Email = customer_Email;
    }
    
    public String getCustomer_Password() {
        return customer_Password;
    }
    public void setCustomer_Password(String customer_Password) {
        this.customer_Password = customer_Password;
    }
        
    //Parameter Constructor
    public CustomerLogin(String customer_Email, String customer_Password) {
        super();
        this.customer_Email = customer_Email;
        this.customer_Password = customer_Password;
    }
    
    //Default Constructor
    public CustomerLogin() {
        super();
    }
    
    //toString
    @Override
    public String toString() {
        return "CustomerLogin [customer_Email=" + customer_Email + ", customer_Password=" + customer_Password + "]";
    }
    
}