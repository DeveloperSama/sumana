package com.cap.service;

import com.cap.entities.Customer;

public interface CustomerService  {

	public Customer getCustomerByCustomerId(int customerId);

}
