package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="capstore_merchants")
public class Merchant  {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "merchant_seq_gen")
	@SequenceGenerator(name = "merchant_seq_gen", initialValue = 1000, sequenceName = "merchant_seq_gen")
	private int merchant_Id;
	@Column
	private String merchantName;
	@Column
	private String emailid;
	@Column
    private String Password;
	
	@Column/*(unique=true)
	@NotNull*/
	private String ConfirmPassword;
	@Column
	private String PhoneNumber;
	@Column
	private String CompanyName;
	@Column
	private int Discount;
	@Column
	private String AadharNumber;
	
	public int getMerchant_Id() {
		return merchant_Id;
	}
	public void setMerchant_Id(int merchant_Id) {
		this.merchant_Id = merchant_Id;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getConfirmPassword() {
		return ConfirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		ConfirmPassword = confirmPassword;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public int getDiscount() {
		return Discount;
	}
	public void setDiscount(int discount) {
		Discount = discount;
	}
	public String getAadharNumber() {
		return AadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		AadharNumber = aadharNumber;
	}
	
	
	
}
