package com.cap.dao;

import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cap.entities.TransactionDetails;

@Repository("transactionRepo")
@Transactional
public interface TransactionRepo extends JpaRepository<TransactionDetails,Integer>{

	Optional<TransactionDetails> findByTransactionId(long transactionId);

	/*@Query("select count(*) from TransactionDetails where invoice=:invoice")
	public TransactionDetails getTransactionFromInvoice(InvoiceDetails invoice);*/

}