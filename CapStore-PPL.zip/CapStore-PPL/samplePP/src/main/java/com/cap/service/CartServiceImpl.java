package com.cap.service;

import org.springframework.stereotype.Service;

@Service("cartService")
public class CartServiceImpl implements CartService {

	@Override
	public double calculateTotalCartAmount(double totalAmount) {
		// TODO Auto-generated method stub
		return 0;
	}

}
