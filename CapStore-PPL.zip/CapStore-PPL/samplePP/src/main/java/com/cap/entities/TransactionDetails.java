package com.cap.entities;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import net.minidev.json.annotate.JsonIgnore;

@Entity
@Table(name = "capstore_transaction")
public class TransactionDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "transaction_seq_gen")
	@SequenceGenerator(name = "transaction_seq_gen", initialValue = 100, sequenceName = "transaction_seq")
	private long transactionId;


	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	 @JoinColumn(name="productId",referencedColumnName="productId")
	 @OnDelete(action = OnDeleteAction.CASCADE)
	 @JsonIgnore
	 private Product product;
	    

	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	 @JoinColumn(name="merchant_Id",referencedColumnName="merchant_Id")
	 @OnDelete(action = OnDeleteAction.CASCADE)
	 @JsonIgnore
	 private Merchant merchant;
	 

	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	 @JoinColumn(name="orderId",referencedColumnName="orderId")
	 @OnDelete(action = OnDeleteAction.CASCADE)
	 @JsonIgnore
	 private Order order;
	 
	
	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	 @JoinColumn(name="customer_Id",referencedColumnName="customer_Id")
	 @OnDelete(action = OnDeleteAction.CASCADE)
	 @JsonIgnore
	 private Customer customer;

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public TransactionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TransactionDetails(long transactionId, double totalAmount, String paymentMode, Product product,
			Merchant merchant, Order order, Customer customer) {
		super();
		this.transactionId = transactionId;
		this.product = product;
		this.merchant = merchant;
		this.order = order;
		this.customer = customer;
	}
	 
}
