package com.cap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.CustomerRepo;
import com.cap.entities.Customer;



@Service
public class EditCustomerProfileImpl implements EditCutomerProfile {

	@Autowired
	CustomerRepo dao;

	Customer customer;
	
	public Customer editCustomerProfile(String customer_Email, String customer_Name,String customer_HomeAddress,
		String customer_ShippingAddress, String customer_MobileNumber) {
		
		customer=dao.editCustomerProfile(customer_Email,customer_Name, customer_HomeAddress, customer_ShippingAddress, customer_MobileNumber);
		String cust_Email=customer.getCustomer_Email();
		
		if(cust_Email.equals(customer_Email)) {
			customer.setCustomer_Name(customer_Name);
			customer.setCustomer_HomeAddress(customer_HomeAddress);
			customer.setCustomer_ShippingAddress(customer_ShippingAddress);
			customer.setCustomer_MobileNumber(customer_MobileNumber);
			dao.save(customer);
		}
		return customer;
		
	}

}
