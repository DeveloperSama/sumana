package com.cap.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cap.dao.FeedBackRepo;
import com.cap.entities.FeedBack;

@Service("feedBackService")
public class FeedBackServiceImpl implements FeedBackService {
	
	@Autowired
	private FeedBackRepo feedBackRepo;

	@Override
	public void submitFeedback(FeedBack feedBack) {
			feedBackRepo.save(feedBack);
	}

	@Override
	public double calculateProductRating(int productId) {
		double averageRating = 0;
		int sum=0;
		int feedbacksNumber=0;
		
		List<FeedBack> feedbacks = feedBackRepo.findByProductId(productId);
		
		for(FeedBack myFeedback:feedbacks) {
				
			sum += myFeedback.getRating();
			feedbacksNumber++;
		}
		
		if(feedbacksNumber!=0) {
			averageRating = (double)((double)sum/feedbacksNumber);
		}
		
		return averageRating;
	}

	@Override
	public List<FeedBack> getAllFeedbacks(int productId) {
		 return feedBackRepo.getAllFeedbacks(productId);
	}

	@Override
	public List<FeedBack> getAllFeedbacksOrderByMerchantId() {
		return feedBackRepo.findAllOrderByMerchantId();
	}

	@Override
	public List<Long> getNumberOfFeedbacksPerMerchant() {
		List<Long> numberOfFeedbacksPerMerchant=feedBackRepo.numberOfFeedbacksPerMerchant();//new LinkedList<Integer>();
		return numberOfFeedbacksPerMerchant;
	}

	@Override
	public List<FeedBack> getAllFeedbacksOfMerchant(int merchant_Id) {
		return feedBackRepo.findByMerchantId(merchant_Id);
	}

}
