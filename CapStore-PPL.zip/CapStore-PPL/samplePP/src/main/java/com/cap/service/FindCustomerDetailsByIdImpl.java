package com.cap.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.CustomerRepo;
import com.cap.entities.Customer;


@Service("findCustomerDetailsById")
public class FindCustomerDetailsByIdImpl implements FindCustomerDetailsById{

	@Autowired
	CustomerRepo dao;
	
	Optional<Customer> customer;
	
	
	Customer cust_Reg;
	
	public Customer findCustomerById(long customer_Id) {
		customer=dao.findById(customer_Id);
		long cust_Id=customer.get().getCustomer_Id();
		if(cust_Id==customer_Id) {
			cust_Reg=customer.get();
		}
		return cust_Reg;
	}

}
