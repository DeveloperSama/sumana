package com.cap.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entities.Customer;
import com.cap.service.EditCutomerProfile;
import com.cap.service.FindCustomerDetailsById;
import com.cap.service.ForgotPassword;
import com.cap.service.SignIn;
import com.cap.service.SignUp;
import com.cap.service.UpdatePassword;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/capstore")
public class CustomerController {
	
	@Autowired
	SignUp signUp_Service;
	
	@Autowired
	SignIn signIn_Service;
	
	@Autowired 
	ForgotPassword forgot_Service;
	
	@Autowired
	UpdatePassword update_Service;
	
	@Autowired
	EditCutomerProfile edit_Service;
	
	@Autowired
	FindCustomerDetailsById findCust_Service;
	
	
	@PostMapping("/createCustomerAccount")
	public Customer createCustomerAccount(@RequestBody Customer custReg) {
		return signUp_Service.createCustomerAccount(custReg);
	}
	
	@GetMapping("/login/{customer_Email}/{customer_Password}")
	public Customer findByCustomerEmail(@PathVariable String customer_Email,@PathVariable String customer_Password) {
		return signIn_Service.findByCustomerEmail(customer_Email, customer_Password);
	}
	
	
	@PutMapping("/forgotpasswordbyemail/{customer_Email}/{customer_Password}")
	public Customer findByCustomerEmailForPasswd(@PathVariable String customer_Email, @PathVariable String customer_Password) {
		return forgot_Service.findByCustomerEmailForPasswd(customer_Email, customer_Password);
	}
	
	@PutMapping("/forgotpasswordbymobnum/{customer_MobileNumber}/{customer_Question}/{customer_Answer}/{customer_Password}")
	public Customer findByCustomerMobNum(@PathVariable String customer_MobileNumber,@PathVariable String customer_Question,
			@PathVariable String customer_Answer,@PathVariable String customer_Password) {
		return forgot_Service.findByCustomerMobNum(customer_MobileNumber, customer_Question, customer_Answer, customer_Password);
	}
	
	
	@PutMapping("/updatepassword/{customer_Email}/{customer_Password}/{customer_ReEnterPassword}")
	public Customer updateCustomerPassword(@PathVariable String customer_Email,@PathVariable String customer_Password,@PathVariable String customer_ReEnterPassword) {
		return update_Service.updateCustomerPassword(customer_Email, customer_Password, customer_ReEnterPassword);
	}
	
	
	@PutMapping("/editprofile/{customer_Email}/{customer_Name}/{customer_HomeAddress}/{customer_ShippingAddress}/{customer_MobileNumber}")
	public Customer editCustomerProfile(@PathVariable String customer_Email,@PathVariable String customer_Name,@PathVariable String customer_HomeAddress,
			@PathVariable String customer_ShippingAddress,@PathVariable String customer_MobileNumber)
	{
		
		return edit_Service.editCustomerProfile(customer_Email,customer_Name,customer_HomeAddress, customer_ShippingAddress, customer_MobileNumber);
	}
	
	
	@GetMapping("/findcustomerbyid/{customer_Id}")
	public Customer findCustomerById(@PathVariable long customer_Id) {
		return findCust_Service.findCustomerById(customer_Id);
	}
}
