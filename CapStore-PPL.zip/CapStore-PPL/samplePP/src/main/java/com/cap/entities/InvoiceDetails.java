package com.cap.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import com.fasterxml.jackson.annotation.JsonFormat;
import net.minidev.json.annotate.JsonIgnore;

@Entity
@Table(name="capstore_invoice")
public class InvoiceDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "invoice_seq_gen")
	@SequenceGenerator(name = "invoice_seq_gen", initialValue = 100, sequenceName = "invoice_seq")
	private long invoiceId;
	
	@JsonFormat(pattern="dd-MM-yyyy")
	private Date invoiceDate;	
	
	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	 @JoinColumn(name="transactionId",referencedColumnName="transactionId")
	 @OnDelete(action = OnDeleteAction.CASCADE)
	 @JsonIgnore	 
	 private TransactionDetails transaction;
	 
	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	 @JoinColumn(name="productId",referencedColumnName="productId")
	 @OnDelete(action = OnDeleteAction.CASCADE)
	 @JsonIgnore
	 private Product product;
	    

	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	 @JoinColumn(name="merchant_Id",referencedColumnName="merchant_Id")
	 @OnDelete(action = OnDeleteAction.CASCADE)
	 @JsonIgnore
	 private Merchant merchant;
	 

	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	 @JoinColumn(name="orderId",referencedColumnName="orderId")
	 @OnDelete(action = OnDeleteAction.CASCADE)
	 @JsonIgnore
	 private Order order;
	 
	
	 @ManyToOne(fetch = FetchType.LAZY, optional = false)
	 @JoinColumn(name="customer_Id",referencedColumnName="customer_Id")
	 @OnDelete(action = OnDeleteAction.CASCADE)
	 @JsonIgnore
	 private Customer customer;

	public InvoiceDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public long getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(long invoiceId) {
		this.invoiceId = invoiceId;
	}

	public TransactionDetails getTransaction() {
		return transaction;
	}

	public void setTransaction(TransactionDetails transaction) {
		this.transaction = transaction;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setinvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public InvoiceDetails(long invoiceId, Date invoiceDate, TransactionDetails transaction, Product product,
			Merchant merchant, Order order, Customer customer) {
		super();
		this.invoiceId = invoiceId;
		this.invoiceDate = invoiceDate;
		this.transaction = transaction;
		this.product = product;
		this.merchant = merchant;
		this.order = order;
		this.customer = customer;
	}
}
