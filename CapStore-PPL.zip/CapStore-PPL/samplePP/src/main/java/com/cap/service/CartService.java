package com.cap.service;

public interface CartService {

	public double calculateTotalCartAmount(double totalAmount);

}
