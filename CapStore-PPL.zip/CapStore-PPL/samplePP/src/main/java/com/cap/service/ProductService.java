package com.cap.service;

import com.cap.entities.Product;

public interface ProductService {

	public Product getProduct(int productId);

}
