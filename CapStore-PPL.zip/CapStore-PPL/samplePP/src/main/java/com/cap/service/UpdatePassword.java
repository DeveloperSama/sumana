package com.cap.service;

import com.cap.entities.Customer;

public interface UpdatePassword {
	public Customer updateCustomerPassword(String customer_Email,String customer_Password,String customer_ReEnterPassword);
}
