package com.cap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.CustomerRepo;
import com.cap.entities.Customer;
import com.cap.util.Encryption;


@Service("forgetPassword")
public class ForgotPasswordImpl implements ForgotPassword{
	
	@Autowired
	CustomerRepo dao;
	

	Customer customer;
	
	public Customer findByCustomerEmailForPasswd(String customer_Email, String customer_Password) {
		customer=dao.findByCustomerEmailForPasswd(customer_Email, customer_Password);
		String cust_Email=customer.getCustomer_Email();
		if(cust_Email.equals(customer_Email)) {
			customer.setCustomer_Password(Encryption.encrypt(customer.getCustomer_Password()));
			customer.setCustomer_ReEnterPassword(Encryption.encrypt(customer.getCustomer_ReEnterPassword()));
			dao.save(customer);
		}
		return customer;
	}


	public Customer findByCustomerMobNum(String customer_MobileNumber, String customer_Question,
			String customer_Answer, String customer_Password) {
		customer=dao.findByCustomerMobNum(customer_MobileNumber, customer_Question, customer_Answer, customer_Password);
		String cust_MobNum=customer.getCustomer_MobileNumber();
		String cust_Question=customer.getCustomer_Question();
		String cust_Answer=customer.getCustomer_Answer();
		if(cust_MobNum.equals(customer_MobileNumber)&&cust_Question.equals(customer_Question)&&cust_Answer.equals(customer_Answer)) {
			customer.setCustomer_Password(Encryption.encrypt(customer.getCustomer_Password()));
			customer.setCustomer_ReEnterPassword(Encryption.encrypt(customer.getCustomer_ReEnterPassword()));
			dao.save(customer);
		}
		return customer;
	}
}
