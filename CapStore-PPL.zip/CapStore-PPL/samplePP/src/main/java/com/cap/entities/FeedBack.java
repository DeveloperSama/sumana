package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import net.minidev.json.annotate.JsonIgnore;

@Entity
@Table(name="capstore_feedbacks")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class FeedBack {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "feedback_seq_gen")
	@SequenceGenerator(name = "feedback_seq_gen", initialValue = 100, sequenceName = "feedback_seq")
	private long feedBackId;
	
	@Column(length=20)
	 private String name;
	
	/*@Column(length=20, nullable=false)
	private int merchant_Id;
	
	@Column(length=20, nullable=false)
	private int productId;*/
		
	@Column
	@Min(150)
	@Max(1000)
	private String feedBackComment;

	 @Column(length=10)
	 private float rating;
	 
	 @OneToOne(targetEntity=Product.class)
	 @JoinColumn(name="productId",referencedColumnName="productId")
	 @JsonIgnore
	 private Product product;
	    

	 @ManyToOne(targetEntity=Merchant.class)
	 @JoinColumn(name="merchant_Id",referencedColumnName="merchant_Id")
	 @JsonIgnore
	 private Merchant merchant;

	 @ManyToOne(targetEntity=Customer.class)
	 @JoinColumn(name="customer_Id",referencedColumnName="customer_Id")
	 @JsonIgnore
	 private Customer customer;

	public long getFeedBackId() {
		return feedBackId;
	}

	public void setFeedBackId(long feedBackId) {
		this.feedBackId = feedBackId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFeedBackComment() {
		return feedBackComment;
	}

	public void setFeedBackComment(String feedBackComment) {
		this.feedBackComment = feedBackComment;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public FeedBack() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FeedBack(long feedBackId, String name, @Min(150) @Max(1000) String feedBackComment, float rating,
			Product product, Merchant merchant, Customer customer) {
		super();
		this.feedBackId = feedBackId;
		this.name = name;
		this.feedBackComment = feedBackComment;
		this.rating = rating;
		this.product = product;
		this.merchant = merchant;
		this.customer = customer;
	}
}
